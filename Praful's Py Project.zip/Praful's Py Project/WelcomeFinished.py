# Import Buttons
import tkinter
from tkinter import *
import random

# Created a window that asks for users name, greets them and stores the name
window = Tk()

window.title("Welcome")
window.geometry('1000x500')  # the windows parameters
lbl = Label(window, text="What is your name?")  # asks for their name
lbl.place(relx=0.5, rely=0.5, anchor=CENTER)  # position of label
txt = Entry(window, width=20)  # entry box for users name
txt.place(relx=0.49, rely=0.4, anchor=CENTER)  # poison of entry box
ticks = 0


def destroy():  # This command is used to get rid of the welcome window after user gets greeted
    window.destroy()


def clicked():  # command for button to print to greet user
    global ticks
    try:
        int(txt.get())  # if it is able to turn the input into a integer than tells user to enter again.
        lbl.configure(text="Please enter a valid name not numbers!", fg="red")
        ticks = 0  # resets ticks to 0
        print(ticks)  # prints the ticks
    except ValueError:
        if not txt.get():  # if nothing is entered tell user to enter name
            ticks = 0
            lbl.configure(text="Please enter a Valid name!", fg="red")
            print(ticks)
        else:
            res = txt.get()  # their name
            greetings = ["Bonjour ", "Hello ", "Gdday ", "Ohayo Gozaimasu ", "Ni hao ", "Hola ",
                         "Ciao "]  # hello in other languages
            randgreeting = random.choice(greetings)  # randomly greets the user
            Greet = randgreeting + res + '!'  # greets the user
            lbl.configure(text=Greet)  # replaces text with greet
            print(ticks)  # prints the ticks
            txt.destroy()  # destroys the entry box
            btn.configure(text="Continue", command=destroy)  # when btn is pressed it destroys the window
            print(ticks)  # prints the ticks
            btn.place(relx=0.5, rely=0.60, anchor=CENTER)  # places the button next to the name
            lbl.configure(fg="black")  # makes the greeting in black font


btn = Button(window, text="Click Me", command=clicked)  # First button you press after entering name
btn.place(relx=0.6, rely=0.4, anchor=CENTER)  # it positioning next to entry box

window.mainloop()
# run the welcome window and destroy itself after

# All the windows Parameters for window 1
window1 = Tk()
window1.title("Pocket Animal (Pokimals) Intro")
window1.geometry('1000x500')
lbl1 = Label(window1, text="...", font=("Bahnschrift", 10))
lbl1.grid(column=0, row=0)  # label placement

# The different texts I want to print
texts = ['Welcome to Pocket Animals also known as Pokimals! \n',
         'Pokimals is a 1v1 fighting game where you choose your Pokimal '
         'and go head to head against a friend and fight it out to see who comes out onto! \n',
         'If you are ready click the start button to get going.\n', 'Good Luck Adventurer!\n']


def start():  # last button that destroys the information window and starts the game
    print("Start")
    window1.destroy()  # closes window 1


# setting the counter for the different texts I want to print
counter = 0


def W1():  # defines the button command that goes through the different strings i want to show
    global counter
    btn1.configure(text="🠻", command=W1, font=30)
    lbl1.configure(text=texts[counter])  # prints the position of the text corresponding to the counter
    print("Welcome", counter)  # prints the counter in terminal
    counter += 1  # adds counter each time this command is run to print the next text
    if counter >= 3:
        btn1.configure(text="Start", command=start, bg="orange",
                       font=20)  # when its gone through all the texts it closes
        counter += 1  # adds to the counter once more to stop the code


btn1 = Button(window1, text="Hello Adventurer!", bg="orange", fg="white", command=W1)  # first button
btn1.place(relx=0.5, rely=0.5, anchor=CENTER)  # centered the button

window1.mainloop()
