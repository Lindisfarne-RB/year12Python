from tkinter import *
from tkinter.ttk import *
from PIL import ImageTk, Image
from tkinter import filedialog
import winsound
import mysql.connector
from datetime import datetime

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Ns!8xF7Q",
  database="digitech_roject"
)

master = Tk()
master.geometry("500x500")
master.title("Z-Map")

column_padd = 20
column_paddy = 10

def openuploadwindow():
    global mydb
    global root
    global column_padd
    global column_paddy
    global file_path
    global file_open_button
    global name_of_map_title
    global name_of_country
    root = Toplevel(master)
    root.geometry("800x500")
    root.title("Upload a file")


    def open_image():
        global root
        global column_padd
        global Label
        global img
        global map
        root.filename = filedialog.askopenfile(initialdir="/", title="Z-Map - Select a File", filetypes=(("jpg file", "*.jpg"), ("png files", "*.png")))
        map = root.filename.name
        Label = Label(root, text=map).grid(column=0, row=1)
        canvas = Canvas(root)
        canvas.grid(column=3, row=2, rowspan=100, padx=column_padd, pady=column_paddy)
        img = ImageTk.PhotoImage(Image.open(map))
        canvas.create_image(50, 50, anchor=NW, image=img)

    file_path = Label(root, text="Upload a file").grid(column=0, row=0, padx=column_padd, pady=column_paddy)
    browse_input = Entry(root, width=50)
    browse_input.grid(column=0, row=1, padx=column_padd, pady=column_paddy)

    file_open_button = Button(root, text="Browse", command=open_image).grid(column=1, row=1, padx=column_padd,
                                                                            pady=column_paddy)
    name_of_map_title = Label(root, text="Name of Map").grid(column=0, row=2, padx=column_padd, pady=column_paddy)
    name_of_map_input = Entry(root, width=50)
    name_of_map_input.grid(column=0, row=3, padx=column_padd, pady=column_paddy)

    # code for drop-down menu
    country_frame = Frame(root)
    country_frame.grid(column=0, row=4, padx=column_padd, pady=column_paddy)
    country_frame.columnconfigure(0, weight=1)
    country_frame.rowconfigure(0, weight=1)
    countryvar = StringVar(root)
    country_choices = {'', 'New Zealand', 'Australia', 'Finland', 'Estonia'}
    countryvar.set(' ')
    country_menu = OptionMenu(country_frame, countryvar, *country_choices)
    Label(country_frame, text="What country is your map from?").grid(column=0, row=1)
    country_menu.grid(column=1, row=1)
    name_of_country = countryvar.get()

    # code for date input
    date_of_map_title = Label(root, text="Enter date in DD-MM-YYYY format")
    date_of_map_title.grid(column=0, row=5, padx=column_padd, pady=column_paddy)
    date_of_map = Entry(root, width=50)
    date_of_map.grid(column=0, row=6, padx=column_padd, pady=column_paddy)

    #  date_of_map_entry = date_of_map.get()
    # str(date_of_map_entry)
    # date = datetime.strptime(date_of_map_entry, "%d-%m-%y")

    # function to get info when 'submit' is pressed
    def myClick():
        global name_of_map_final
        global date_of_map_final
        global final_country
        name_of_map_final = name_of_map_input.get()
        date_of_map_final = date_of_map.get()
        final_country = countryvar.get()
        print(date_of_map_final)
        print(final_country)
        print(name_of_map_final)
        winsound.PlaySound("SystemExclamation", winsound.SND_ALIAS)
        root.destroy()

    # submit button
    submit = Button(root, text="Submit", command=myClick, width="30")
    submit.grid(column=0, row=7, padx=column_padd, pady=column_paddy)

    mycursor = mydb.cursor()
    sql = "INSERT INTO map_data (map_name, map_date, map_country, map_path) VALUES (%s, %s, %s, %s)"
    val = (name_of_map_final, date_of_map_final, final_country, map)
    mycursor.execute(sql, val)

    mydb.commit()

# code to open 'upload window'
uploadButton = Button(master, text="Upload a file", command=openuploadwindow)
uploadButton.grid(column=0, row=3, padx=column_padd, pady=column_paddy)

# code for info of app
title_app = Label(master, text="Z-map", font=("Arial", 25))
title_app.grid(column=0, row=0, padx=column_padd, pady=column_paddy)
description_app = Label(master, text="This app can help you to store your maps in an easy to view manner.")
description_app.grid(column=0, row=1, padx=column_padd, pady=column_paddy)



master.mainloop()