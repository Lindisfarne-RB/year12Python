import sqlite3
from tkinter import *
from tkinter import filedialog
from tkinter.ttk import *
from PIL import ImageTk,Image

master = Tk()

# variables for page setup
column_pad = 20
row_pad = 10

connection = sqlite3.connect('map_database.db')

c = connection.cursor()
'''
c.execute("""CREATE TABLE map_info(
    map_location_name text,
    map_competition_name,
    map_location text,
    map_path text,
    map_date integer,
    map_type text,
    map_region text)""")
'''


def upload_file():
    # opens a new window
    root = Toplevel(master)
    root.title("Z-Map Upload a file")

    # input fields
    # input for name of location of map
    m_location_name = Entry(root, width=50)
    m_location_name.grid(row=0, column=1, padx=column_pad, pady=row_pad)
    # input for name of competition of map
    m_competition_name = Entry(root, width=50)
    m_competition_name.grid(row=1, column=1, padx=column_pad, pady=row_pad)
    # drop-down for country of map
    country_frame = Frame(root)
    country_frame.grid(column=1, row=2, padx=column_pad, pady=row_pad)
    country_frame.columnconfigure(0, weight=1)
    country_frame.rowconfigure(0, weight=1)
    countryvar = StringVar(root)
    country_choices = {'', 'New Zealand', 'Australia', 'Finland', 'Estonia'}
    countryvar.set(' ')
    country_menu = OptionMenu(country_frame, countryvar, *country_choices)
    Label(country_frame, text="What country is your map from?  ").grid(column=0, row=1)
    country_menu.grid(column=1, row=1)
    name_of_country = countryvar.get()
    # drop-down for region of map
    region_frame = Frame(root)
    region_frame.grid(column=1, row=3, padx=column_pad, pady=row_pad)
    region_frame.columnconfigure(0, weight=1)
    region_frame.rowconfigure(0, weight=1)
    regionvar = StringVar(root)
    region_choices = {'', 'Northland', 'Auckland', 'Waikato', 'Napier', 'Palmerston North', 'Wellington', 'Nelson', 'Christchurch', 'Otago', 'Other', 'Not NZ'}
    regionvar.set(' ')
    region_menu = OptionMenu(region_frame, regionvar, *region_choices)
    Label(region_frame, text="What region is your map from?  ").grid(column=0, row=1)
    region_menu.grid(column=1, row=1)
    name_of_region = regionvar.get()
    # input for date of map
    m_date = Entry(root, width=50)
    m_date.grid(column=1, row=4, padx=column_pad, pady=row_pad)
    # upload a file button

    def open_image():
        root.filename = filedialog.askopenfile(initialdir="/", title="Z-Map - Select a File", filetypes=(("jpg file", "*.jpg"), ("png files", "*.png")))
        map = root.filename.name
        map_short = map
        for i in range(0, len(map_short)-25):
            map = map
            # get miss to help remove characters to shorten string so path can be viewed easily
        m_path = Label(root, text=map)
        m_path.grid(column=0, row=6, padx=column_pad, pady=row_pad, columnspan=2)
    # opens a file dialogue box
    file_open_button = Button(root, width=60, text="Browse", command=open_image)
    file_open_button.grid(column=0, row=5, padx=column_pad, pady=row_pad, columnspan=2)
    # end of input fields
    # label for text inputs
    # text for map location
    m_location_label = Label(root, text="What is the name of your map?")
    m_location_label.grid(row=0, column=0, padx=column_pad, pady=row_pad)
    # text for competition name
    m_competition_label = Label(root, text="What series / competition was this from?")
    m_competition_label.grid(row=1, column=0, padx=column_pad, pady=row_pad)
    # text for date of map
    m_date_label = Label(root, text="What date is your map from? (YYYY-MM-DD)")
    m_date_label.grid(row=4, column=0, padx=column_pad, pady=row_pad)
    # submit button

    def submit():
        root.destroy()
        c.execute("INSERT INTO map_info VALUES")
    submit = Button(root, width=90, text="Submit", command=submit)
    submit.grid(row=7, column=0, padx=column_pad, pady=row_pad, columnspan=2)


upload = Button(master, width=30, text="Upload a file", command=upload_file)
upload.grid(column=10, row=10)

connection.commit()

connection.close()

master.mainloop()