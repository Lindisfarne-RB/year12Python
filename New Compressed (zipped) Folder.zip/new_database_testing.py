import sqlite3
from tkinter import *
from PIL import ImageTk,Image

root = Tk()

connection = sqlite3.connect('map_database.db')

c = connection.cursor()

c.execute("""CREATE TABLE mpa_info(
    map_name text,
    map_location text,
    map_path text,
    map_date integer)""")

connection.commit()

connection.close()

root.mainloop()