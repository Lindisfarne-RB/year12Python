import sqlite3
from tkinter import *
from tkinter import filedialog
from tkinter.ttk import *
from PIL import ImageTk,Image

root = Tk()

# variables for page setup
column_pad = 20
row_pad = 10

connection = sqlite3.connect('map_database.db')

c = connection.cursor()
'''
c.execute("""CREATE TABLE mpa_info(
    map_name text,
    map_location text,
    map_path text,
    map_date integer)""")
'''
def upload_file():
    # input fields
    # input for name of map
    m_name = Entry(root, width=50)
    m_name.grid(row=0, column=0, padx=column_pad, pady=row_pad)
    # drop-down for country of map
    country_frame = Frame(root)
    country_frame.grid(column=0, row=1, padx=column_pad, pady=row_pad)
    country_frame.columnconfigure(0, weight=1)
    country_frame.rowconfigure(0, weight=1)
    countryvar = StringVar(root)
    country_choices = {'', 'New Zealand', 'Australia', 'Finland', 'Estonia'}
    countryvar.set(' ')
    country_menu = OptionMenu(country_frame, countryvar, *country_choices)
    Label(country_frame, text="What country is your map from?  ").grid(column=0, row=1)
    country_menu.grid(column=1, row=1)
    name_of_country = countryvar.get()
    # input for date of map
    m_date = Entry(root, width=50)
    m_date.grid(column=0, row=2, padx=column_pad, pady=row_pad)
    # upload a file button

    def open_image():
        root.filename = filedialog.askopenfile(initialdir="/", title="Z-Map - Select a File", filetypes=(("jpg file", "*.jpg"), ("png files", "*.png")))
        map = root.filename.name
        map_short = map
        
        m_path = Label(root, text=map)
        m_path.grid(column=0, row=4, padx=column_pad, pady=row_pad)
    file_open_button = Button(root, text="Browse", command=open_image)
    file_open_button.grid(column=0, row=3, padx=column_pad, pady=row_pad)
    # end of input fields
    # label for text inputs

upload = Button(root, width=30, text="Upload a file", command=upload_file)
upload.grid(column=10, row=10)

connection.commit()

connection.close()

root.mainloop()