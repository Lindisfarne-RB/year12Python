from tkinter import ttk
from tkinter import *
import tkinter as tk
import sqlite3


def connect():
    connection = sqlite3.connect("map_database.db")
    c = connection.cursor()

    connection.commit()
    connection.close()


def view_date():
    connection = sqlite3.connect("map_database.db")
    c = connection.cursor()

    c.execute("SELECT * FROM map_info ORDER BY map_date DESC")
    rows = c.fetchall()

    for row in table.get_children():
        table.delete(row)
    for row in rows:
        table.insert("", tk.END, values=row)

    connection.close()


def view_type():
    connection = sqlite3.connect("map_database.db")
    c = connection.cursor()

    c.execute("SELECT * FROM map_info ORDER BY map_type")
    rows = c.fetchall()
    for row in table.get_children():
        table.delete(row)
    for row in rows:
        table.insert("", tk.END, values=row)

    connection.close()


# connect to the database
connect()

view_window = Tk()
view_window.title("Z-Map Map Viewer")


sort_date = tk.Button(text="Display data", command=view_date)
sort_date.grid(row=0, column=0, pady=10)

sort_name = Button(text="Sort by name", command=view_type)
sort_name.grid(row=0, column=1, pady=10)


table = ttk.Treeview(view_window, column=("c1", "c2", "c3", "c4", "c5", "c6", "c7"), show='headings')

table.column("#1", anchor=tk.CENTER)
table.heading("#1", text="Location of Map")

table.column("#2", anchor=tk.CENTER)
table.heading("#2", text="Name of competition")

table.column("#3", anchor=tk.CENTER)
table.heading("#3", text="Country")

table.column("#4", anchor=tk.CENTER)
table.heading("#4", text="Image path")

table.column("#5", anchor=tk.CENTER)
table.heading("#5", text="Date")

table.column("#6", anchor=tk.CENTER)
table.heading("#6", text="Type of Map")

table.column("#7", anchor=tk.CENTER)
table.heading("#7", text="Region")

table.grid(row=1, column=0, columnspan=2)

view_window.mainloop()
