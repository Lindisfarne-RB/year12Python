import sqlite3
from tkinter import *
from tkinter import filedialog
from tkinter.ttk import *
from PIL import ImageTk,Image

master = Tk()

# variables for page setup
column_pad = 20
row_pad = 10

connection = sqlite3.connect('map_database.db')

c = connection.cursor()
'''
c.execute("""CREATE TABLE map_info(
    map_location_name text,
    map_competition_name,
    map_location text,
    map_path text,
    map_date integer,
    map_type text,
    map_region text)""")
'''


def upload_file():
    # opens a new window
    root = Toplevel(master)
    root.title("Z-Map Upload a file")

    # input fields
    # input for name of location of map
    m_location_name = Entry(root, width=50)
    m_location_name.grid(row=0, column=1, padx=column_pad, pady=row_pad)
    # input for name of competition of map
    m_competition_name = Entry(root, width=50)
    m_competition_name.grid(row=1, column=1, padx=column_pad, pady=row_pad)
    # drop-down for country of map
    country_frame = Frame(root)
    country_frame.grid(column=1, row=2, padx=column_pad, pady=row_pad)
    country_frame.columnconfigure(0, weight=1)
    country_frame.rowconfigure(0, weight=1)
    country_var = StringVar(root)
    country_choices = {'', 'New Zealand', 'Australia', 'Finland', 'Estonia'}
    country_var.set(' ')
    country_menu = OptionMenu(country_frame, country_var, *country_choices)
    Label(country_frame, text="What country is your map from?  ").grid(column=0, row=1)
    country_menu.grid(column=1, row=1)
    name_of_country = country_var.get()
    # drop-down for region of map
    region_frame = Frame(root)
    region_frame.grid(column=1, row=3, padx=column_pad, pady=row_pad)
    region_frame.columnconfigure(0, weight=1)
    region_frame.rowconfigure(0, weight=1)
    region_var = StringVar(root)
    region_choices = {'', 'Northland', 'Auckland', 'Waikato', 'Napier', 'Palmerston North', 'Wellington', 'Nelson', 'Christchurch', 'Otago', 'Other', 'Not NZ'}
    region_var.set(' ')
    region_menu = OptionMenu(region_frame, region_var, *region_choices)
    Label(region_frame, text="What region is your map from?  ").grid(column=0, row=1)
    region_menu.grid(column=1, row=1)
    # drop-down for type of map
    type_frame = Frame(root)
    type_frame.grid(column=1, row=4, padx=column_pad, pady=row_pad)
    type_frame.columnconfigure(0, weight=1)
    type_frame.rowconfigure(0, weight=1)
    type_var = StringVar(root)
    type_choices = {'', 'Forest', 'Farm', 'Sprint'}
    type_var.set(' ')
    type_menu = OptionMenu(type_frame, type_var, *type_choices)
    Label(type_frame, text="What type of map is this?  ").grid(column=0, row=1)
    type_menu.grid(column=1, row=1)
    # input for date of map
    m_date = Entry(root, width=50)
    m_date.grid(column=1, row=5, padx=column_pad, pady=row_pad)
    # upload a file button

    def open_image():
        global map_1
        root.filename = filedialog.askopenfile(initialdir="/", title="Z-Map - Select a File", filetypes=(("jpg file", "*.jpg"), ("png files", "*.png")))
        map_1 = root.filename.name
        map_short = map_1
        '''
        for i in range(0, len(map_short)-25):
            map = map
            # get miss to help remove characters to shorten string so path can be viewed easily
        '''
        m_path_label = Label(root, text=map_1)
        m_path_label.grid(column=0, row=7, padx=column_pad, pady=row_pad, columnspan=2)
    # opens a file dialogue box
    file_open_button = Button(root, width=60, text="Browse", command=open_image)
    file_open_button.grid(column=0, row=6, padx=column_pad, pady=row_pad, columnspan=2)
    # end of input fields
    # label for text inputs
    # text for map location
    m_location_label = Label(root, text="What is the name of your map?")
    m_location_label.grid(row=0, column=0, padx=column_pad, pady=row_pad)
    # text for competition name
    m_competition_label = Label(root, text="What series / competition was this from?")
    m_competition_label.grid(row=1, column=0, padx=column_pad, pady=row_pad)
    # text for date of map
    m_date_label = Label(root, text="What date is your map from? (YYYYMMDD)")
    m_date_label.grid(row=5, column=0, padx=column_pad, pady=row_pad)
    # submit button

    def submit():

        connection = sqlite3.connect('map_database.db')
        c = connection.cursor()
        c.execute("INSERT INTO map_info VALUES(:map_location_name, :map_competition_name, :map_location, :map_path, :map_date, :map_type, :map_region)",
                  {
                      'map_location_name': m_location_name.get(),
                      'map_competition_name': m_competition_name.get(),
                      'map_location': country_var.get(),
                      'map_path': map_1,
                      'map_date': m_date.get(),
                      'map_type': type_var.get(),
                      'map_region': region_var.get()
                  })
        connection.commit()
        connection.close()
        root.destroy()
    submit = Button(root, width=90, text="Submit", command=submit)
    submit.grid(row=8, column=0, padx=column_pad, pady=row_pad, columnspan=2)


# Create a query function
def query_upload():
    global data
    connection = sqlite3.connect('map_database.db')
    c = connection.cursor()

    c.execute("SELECT * FROM map_info")
    data = c.fetchall()
    print(data)

    connection.commit()
    connection.close()


def view_files():
    connection = sqlite3.connect('map_database.db')
    c = connection.cursor()

    c.execute("SELECT * FROM map_info")
    data = c.fetchall()

    view_window = Toplevel(master)
    view_window.title("Z-Map View Map Table")

    print_data = ''
    for map_data in data[0]:
        print_data += str(map_data) + "\n"
    map_data_label = Label(view_window, text=print_data)
    map_data_label.grid(row=0, column=0, columnspan=2)

    connection.commit()
    connection.close()


# Create a Query Button
query = Button(master, width=30, text="Did this work", command=query_upload)
query.grid(column=0, row=1)

# Create an upload button
upload = Button(master, width=30, text="Upload a file", command=upload_file)
upload.grid(column=0, row=0)

# Create a 'view table' button
view = Button(master, width=30, text="View maps", command=view_files)
view.grid(column=0, row=2)

connection.commit()

connection.close()

master.mainloop()